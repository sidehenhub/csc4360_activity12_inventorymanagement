import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; 
import 'package:cloud_firestore/cloud_firestore.dart';

// Professor say to Initialize Firebase and Ensure Firebase is initialized before the app starts
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();  

  runApp(InventoryApp()); 
}

class InventoryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inventory Management App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: InventoryHomePage(title: 'Inventory Home Page'),
    );
  }
}

class InventoryHomePage extends StatefulWidget {
  InventoryHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _InventoryHomePageState createState() => _InventoryHomePageState();
}

class _InventoryHomePageState extends State<InventoryHomePage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();

  Future<void> _addItem() async {
    String name = _nameController.text;
    String quantityStr = _quantityController.text;
    int quantity = int.tryParse(quantityStr) ?? 0;

    if (name.isNotEmpty && quantity > 0) {
      await _firestore.collection('inventory').add({
        'name': name,
        'quantity': quantity,
      });
      _nameController.clear();
      _quantityController.clear();
    }
  }

  Future<void> _updateItem(String docId) async {
    String name = _nameController.text;
    String quantityStr = _quantityController.text;
    int quantity = int.tryParse(quantityStr) ?? 0;

    if (name.isNotEmpty && quantity > 0) {
      await _firestore.collection('inventory').doc(docId).update({
        'name': name,
        'quantity': quantity,
      });
      _nameController.clear();
      _quantityController.clear();
    }
  }
  Future<void> _deleteItem(String docId) async {
    await _firestore.collection('inventory').doc(docId).delete();
  }

  Stream<QuerySnapshot> _getInventory() {
    return _firestore.collection('inventory').snapshots();
  }

  void _showItemDialog({String? docId, String? name, int? quantity}) {
    if (name != null && quantity != null) {
      _nameController.text = name;
      _quantityController.text = quantity.toString();
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(docId == null ? 'Add New Item' : 'Edit Item'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Item Name'),
              ),
              TextField(
                controller: _quantityController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Quantity'),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                if (docId == null) {
                  _addItem();
                } else {
                  _updateItem(docId);
                }
                Navigator.of(context).pop();
              },
              child: Text(docId == null ? 'Add Item' : 'Update Item'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _getInventory(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Something went wrong!'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No items in inventory.'));
          }
          final items = snapshot.data!.docs;

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              var item = items[index];
              var name = item['name'];
              var quantity = item['quantity'];
              var docId = item.id;

              return ListTile(
                title: Text(name),
                subtitle: Text('Quantity: $quantity'),
                onTap: () {
                  _showItemDialog(
                    docId: docId,
                    name: name,
                    quantity: quantity,
                  );
                },
                trailing: IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    _deleteItem(docId);
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showItemDialog(); 
        },
        tooltip: 'Add Item',
        child: Icon(Icons.add),
      ),
    );
  }
}
